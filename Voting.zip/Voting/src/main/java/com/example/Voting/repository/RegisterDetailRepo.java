package com.example.Voting.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Voting.entity.RegisterDetail;

@EnableJpaRepositories
@Repository
@Transactional
public interface RegisterDetailRepo extends JpaRepository<RegisterDetail,Integer> {

	public RegisterDetail findByUserName(String username);
	
	@Modifying
	@Query("UPDATE RegisterDetail c SET c.voted = :voted WHERE c.voterid = :voterid")
	int updateVoteStatus(@Param("voterid") int voterid, @Param("voted") String voted);

}
