package com.example.Voting.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.Voting.entity.Candidate;
import com.example.Voting.entity.RegisterDetail;
import com.example.Voting.repository.CandidateRepo;
import com.example.Voting.repository.RegisterDetailRepo;

@Controller
public class MyController {

	@Autowired
	RegisterDetailRepo regdetailrepo;

	@Autowired
	CandidateRepo candidateRepo;

	@GetMapping("/registerpage")
	public String registerPage() {

		return "register";

	}

	@PostMapping("/registerDetail")
	public String registerUser(HttpServletRequest request) {
		String username = request.getParameter("username");
		String psw = request.getParameter("psw");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		RegisterDetail detail = new RegisterDetail();
		detail.setUserName(username);
		detail.setPassword(psw);
		detail.setEmail(email);
		detail.setPhoneno(mobile);
		detail.setVoted("N");
		detail.setVoterid(1);
		System.out.println(username + psw + email + mobile);
		regdetailrepo.save(detail);
		return "login";
	}

	@GetMapping("/loginpage")
	public String loginPage() {

		return "login";

	}

	@PostMapping("/login")
	public ModelAndView login(HttpServletRequest request, ModelAndView mv) {
		String username = request.getParameter("username");
		String psw = request.getParameter("psw");
		HttpSession s = request.getSession();
		List<Candidate> candidates = candidateRepo.findAll();
		System.out.println(candidates);
		for (Candidate c : candidates) {
			mv.addObject(c.getCandidateName(), c.getVotecount());
		}
		if (username.equals("ADMIN") && psw.equals("ADMIN")) {
			s.setAttribute("userid", "ADMIN");
			mv.setViewName("adminPage");
			return mv;
		}

		RegisterDetail detail = regdetailrepo.findByUserName(username);
		if (null != detail && detail.getPassword().equals(psw)) {
			if(detail.getVoted().equals("Y")) {
				s.setAttribute("userid", detail.getVoterid());
				return new ModelAndView("index");
			}
			s.setAttribute("userid", detail.getVoterid());
			return new ModelAndView("votingPage");
		}
		return new ModelAndView("login");

	}

	
	@PostMapping("/votecandidate")
	public String votedToCandidate(HttpServletRequest request) {
		String value = request.getParameter("radio");
		int userid = Integer.parseInt(String.valueOf(request.getSession().getAttribute("userid")));
		Candidate cand = candidateRepo.getById(Integer.parseInt(value));
		System.out.print("userid+"+userid+"cadidateid"+cand.getCandidateid());
		int votecount = 0;
		if (null != cand) {
			votecount = cand.getVotecount() + 1;
			candidateRepo.updateVoteCount(cand.getCandidateid(), votecount);
			regdetailrepo.updateVoteStatus(userid, "Y");
		}

		System.out.println(value);
		return "index";
	}

	@GetMapping("/logout")
	public String logout(HttpServletRequest request) {
		request.getSession().removeAttribute("userid");
		return "index";

	}
}
