package com.example.Voting.dao;

public class Votingdao {
	

}
