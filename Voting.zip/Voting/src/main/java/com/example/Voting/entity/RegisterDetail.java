package com.example.Voting.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RegisterDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int voterid;
	String userName;
	String password;
	String email;
	String phoneno;
	String voted;
	public int getVoterid() {
		return voterid;
	}
	public void setVoterid(int voterid) {
		this.voterid = voterid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getVoted() {
		return voted;
	}
	public void setVoted(String voted) {
		this.voted = voted;
	}
	@Override
	public String toString() {
		return "RegisterDetail [voterid=" + voterid + ", userName=" + userName + ", password=" + password + ", email="
				+ email + ", phoneno=" + phoneno + ", voted=" + voted + "]";
	}
	
	

}
